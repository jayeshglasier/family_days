  <!-- Main Footer -->
		<script src="{{ asset('public/js/jquery.min.js') }}"></script>
		<!-- Bootstrap Core JavaScript -->
		<script src="{{ asset('public/js/bootstrap.min.js') }}"></script>
		<!-- Metis Menu Plugin JavaScript -->
		<script src="{{ asset('public/js/metisMenu.min.js') }}"></script>
		<!-- Morris Charts JavaScript -->
		<script src="{{ asset('public/js/raphael.min.js') }}"></script>
		<script src="{{ asset('public/js/morris.min.js') }}"></script>
		<script src="{{ asset('public/js/morris-data.js') }}"></script>
		<!-- Custom Theme JavaScript -->
		<script src="{{ asset('public/js/startmin.js') }}"></script>
    </body>
</html>