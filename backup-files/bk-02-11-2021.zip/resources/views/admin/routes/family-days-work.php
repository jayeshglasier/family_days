Date : 12-06-2020

- Custom chore doesn't need icon so remove pop up message asking for custom chore icon before saving
Comment: Need to Test 

- When chore icon is selected during chore creation, there shouldn't be a pop up asking for it everytime user views the chore

- There should be "See More" tab after the 6th chore in both assigned and finished chore" section. That "See More" tab will lead to a page where ALL chores within the last year can be viewed.

- add user icon on the upper right portion of the app to help improve user journey (show profile/default pic. Show all chores/rewards/claims). Rename "Dashboard" to "Family Dashboard"

- change time to 12 hour format in admin panel in chores page ------ DONE

- Swap positions of "Parental Approval" and "Mark as Completed" ------ APP SIDE

- check time differences in chores ----- DONE

- if child edits a chore created by parent, it should become black and need to re approval of parent 

- daily chore will be present in assigned chores till the final date(also need to show the final date on assigned chore), completion date will come in the finished chores once a parent or child completes a chore, for daily chore, it can be marked completed on daily basis & rows will be added into finished chore, if parent marks a daily chore as incomplete, that row will be deleted.
Comment: Need to test 

Date : 15-06-2020

At a time 6 assigned & 6 completed chores will be shown in chore tab   ---- DONE
More chores can be seen in clicking on load more button ---- DONE
Chores with predefined list of chores & custom chore ---- DONE
Minimum & maximum limit of chores points --- DONE
Admin can create or edit predefined chores from backend & can change max or min points at any time --- DONE
Parent can set reward with predefined rewards or custom rewards with asking points & date
Children can set reward, but that needs to be confirmed by parent
If a reward is not claimed by any child by a requiste date, then reward become inactive
Rewards maximum & minimum limit to be set
Reward is to be built with dummy brand. not to put into production this time
rewards dump to be put into admin panel